"""Style Match domain package."""
