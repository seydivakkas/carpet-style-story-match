export const FRONTEND_EXPERIENCE_VERSION = "frontend-experience-v1";

export const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";

export const CANONICAL_DIMENSIONS_ORDER = [
  "color_energy",
  "color_diversity",
  "contrast",
  "warmth",
  "visual_complexity",
  "structural_order",
  "rhythm_repetition",
  "focal_strength",
  "form_language"
] as const;

export interface DimensionMetaInfo {
  code: string;
  key: string;
  label_tr: string;
  min_label: string;
  max_label: string;
}

export const DIMENSION_DETAILS: Record<string, DimensionMetaInfo> = {
  color_energy: {
    code: "D1",
    key: "color_energy",
    label_tr: "Renk Enerjisi",
    min_label: "Sakin",
    max_label: "Canlı"
  },
  color_diversity: {
    code: "D2",
    key: "color_diversity",
    label_tr: "Renk Çeşitliliği",
    min_label: "Sade",
    max_label: "Zengin"
  },
  contrast: {
    code: "D3",
    key: "contrast",
    label_tr: "Kontrast",
    min_label: "Yumuşak",
    max_label: "Keskin"
  },
  warmth: {
    code: "D4",
    key: "warmth",
    label_tr: "Sıcaklık",
    min_label: "Soğuk",
    max_label: "Sıcak"
  },
  visual_complexity: {
    code: "D5",
    key: "visual_complexity",
    label_tr: "Görsel Karmaşıklık",
    min_label: "Yalın",
    max_label: "Detaylı"
  },
  structural_order: {
    code: "D6",
    key: "structural_order",
    label_tr: "Yapısal Düzen",
    min_label: "Serbest",
    max_label: "Geometrik"
  },
  rhythm_repetition: {
    code: "D7",
    key: "rhythm_repetition",
    label_tr: "Ritim / Tekrar",
    min_label: "Tekil",
    max_label: "Ritmik"
  },
  focal_strength: {
    code: "D8",
    key: "focal_strength",
    label_tr: "Odak Gücü",
    min_label: "Dağınık",
    max_label: "Odaklı"
  },
  form_language: {
    code: "D9",
    key: "form_language",
    label_tr: "Form Dili",
    min_label: "Geometrik",
    max_label: "Organik"
  }
};

export const CANONICAL_NARRATIVE_THEMES_ORDER = [
  "N1_NATURE_GROWTH",
  "N2_BELONGING_HOME",
  "N3_JOURNEY_DISCOVERY",
  "N4_CONTINUITY_BOND",
  "N5_BALANCE_ORDER",
  "N6_RENEWAL_TRANSFORMATION",
  "N7_TRADITION_CRAFT",
  "N8_CULTURAL_HERITAGE"
] as const;

export interface NarrativeThemeMetaInfo {
  code: string;
  key: string;
  icon: string;
  label_tr: string;
  description: string;
}

export const NARRATIVE_THEME_DETAILS: Record<string, NarrativeThemeMetaInfo> = {
  N1_NATURE_GROWTH: {
    code: "N1",
    key: "N1_NATURE_GROWTH",
    icon: "🌿",
    label_tr: "Doğa & Büyüme",
    description: "Yaşam döngüsü, bitkisel formlar, bereket ve organik hayat motivasyonları."
  },
  N2_BELONGING_HOME: {
    code: "N2",
    key: "N2_BELONGING_HOME",
    icon: "🏠",
    label_tr: "Aidiyet & Yuva",
    description: "Yerleşim, koruma, yuva kurma ve aile bağlarını simgeleyen motifler."
  },
  N3_JOURNEY_DISCOVERY: {
    code: "N3",
    key: "N3_JOURNEY_DISCOVERY",
    icon: "🧭",
    label_tr: "Yolculuk & Keşif",
    description: "Göç, yollar, değişim ve keşif arzusu üzerine kurulu temalar."
  },
  N4_CONTINUITY_BOND: {
    code: "N4",
    key: "N4_CONTINUITY_BOND",
    icon: "🔗",
    label_tr: "Süreklilik & Bağ",
    description: "Kuşaklararası aktarım, sonsuzluk ve sarsılmaz bağlar."
  },
  N5_BALANCE_ORDER: {
    code: "N5",
    key: "N5_BALANCE_ORDER",
    icon: "⚖️",
    label_tr: "Denge & Düzen",
    description: "Geometrik hiyerarşi, merkezcillik ve içsel denge sembolleri."
  },
  N6_RENEWAL_TRANSFORMATION: {
    code: "N6",
    key: "N6_RENEWAL_TRANSFORMATION",
    icon: "✨",
    label_tr: "Yenilenme & Dönüşüm",
    description: "Yeniden doğuş, bahar, değişim ve enerjinin dönüşümü."
  },
  N7_TRADITION_CRAFT: {
    code: "N7",
    key: "N7_TRADITION_CRAFT",
    icon: "🧵",
    label_tr: "Gelenek & Zanaat",
    description: "El emeği, usta-çırak ilişkisi ve dokuma gelenekleri."
  },
  N8_CULTURAL_HERITAGE: {
    code: "N8",
    key: "N8_CULTURAL_HERITAGE",
    icon: "🌍",
    label_tr: "Kültürel Miras",
    description: "Müzeler, tarihsel dönemsellik ve bölgesel üslup kökleri."
  }
};

export const TEXT_CHOICE_LABELS: Record<string, string> = {
  STRONGLY_A: "Kesinlikle Seçenek A",
  SLIGHTLY_A: "Kısmen Seçenek A",
  NEUTRAL: "Nötr / Kararsız",
  SLIGHTLY_B: "Kısmen Seçenek B",
  STRONGLY_B: "Kesinlikle Seçenek B"
};

export const VISUAL_CHOICE_LABELS: Record<string, string> = {
  STRONGLY_LEFT: "Soldaki Görseli Güçlü Tercih Ediyorum",
  SLIGHTLY_LEFT: "Soldaki Görsele Yakınım",
  NEUTRAL: "Eşit / Kararsız",
  SLIGHTLY_RIGHT: "Sağdaki Görsele Yakınım",
  STRONGLY_RIGHT: "Sağdaki Görseli Güçlü Tercih Ediyorum"
};

export const PROVENANCE_LABELS: Record<string, { label_tr: string; color: string }> = {
  INFERRED: { label_tr: "Sistem Çıkarımı", color: "bg-blue-500/20 text-blue-300 border-blue-500/30" },
  USER_CONFIRMED: { label_tr: "Kullanıcı Onayladı", color: "bg-emerald-500/20 text-emerald-300 border-emerald-500/30" },
  USER_OVERRIDDEN: { label_tr: "Kullanıcı Düzenledi", color: "bg-amber-500/20 text-amber-300 border-amber-500/30" }
};
