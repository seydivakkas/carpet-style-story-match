import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "./client";
import {
  HistoricalReferenceListResponse,
  HistoricalReferenceDetailRead,
  HistoricalConnectionDetailRead,
  HistoricalConnectionListResponse,
  HistoricalConnectionMetaResponse,
  ListHistoricalReferencesParams,
  ListHistoricalConnectionsParams
} from "../types/api";

export const historicalKeys = {
  all: ["historical"] as const,
  references: (params?: Record<string, unknown>) => [...historicalKeys.all, "references", params] as const,
  reference: (idOrKey: string) => [...historicalKeys.all, "reference", idOrKey] as const,
  connections: (params?: Record<string, unknown>) => [...historicalKeys.all, "connections", params] as const,
  connection: (id: string) => [...historicalKeys.all, "connection", id] as const,
  meta: () => [...historicalKeys.all, "meta"] as const
};

export function useHistoricalReferences(params?: ListHistoricalReferencesParams) {
  const queryParams = new URLSearchParams();
  if (params?.limit) queryParams.set("limit", String(params.limit));
  if (params?.offset) queryParams.set("offset", String(params.offset));
  if (params?.museum) queryParams.set("museum", params.museum);
  if (params?.institution) queryParams.set("institution", params.institution);
  if (params?.region) queryParams.set("region", params.region);
  if (params?.style_group) queryParams.set("style_group", params.style_group);

  const queryString = queryParams.toString();
  const endpoint = `/api/v1/historical-references${queryString ? `?${queryString}` : ""}`;

  return useQuery({
    queryKey: historicalKeys.references(params),
    queryFn: () => apiRequest<HistoricalReferenceListResponse>(endpoint)
  });
}

export function useHistoricalReference(idOrKey: string) {
  return useQuery({
    queryKey: historicalKeys.reference(idOrKey),
    queryFn: () => apiRequest<HistoricalReferenceDetailRead>(`/api/v1/historical-references/${idOrKey}`),
    enabled: Boolean(idOrKey)
  });
}

// ---------------------------------------------------------
// HISTORICAL CONNECTION HOOKS
// ---------------------------------------------------------
export function useCreateHistoricalConnection() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (payload: { target_style_profile_id: string; historical_reference_id: string }) =>
      apiRequest<HistoricalConnectionDetailRead>("/api/v1/historical-connections", {
        method: "POST",
        body: JSON.stringify(payload)
      }),
    onSuccess: (data) => {
      queryClient.setQueryData(historicalKeys.connection(data.id), data);
      queryClient.invalidateQueries({ queryKey: historicalKeys.connections() });
    }
  });
}

export function useHistoricalConnection(id: string) {
  return useQuery({
    queryKey: historicalKeys.connection(id),
    queryFn: () => apiRequest<HistoricalConnectionDetailRead>(`/api/v1/historical-connections/${id}`),
    enabled: Boolean(id)
  });
}

export function useHistoricalConnections(params?: ListHistoricalConnectionsParams) {
  const queryParams = new URLSearchParams();
  if (params?.limit) queryParams.set("limit", String(params.limit));
  if (params?.offset) queryParams.set("offset", String(params.offset));
  if (params?.target_style_profile_id)
    queryParams.set("target_style_profile_id", params.target_style_profile_id);
  if (params?.historical_reference_id)
    queryParams.set("historical_reference_id", params.historical_reference_id);

  const queryString = queryParams.toString();
  const endpoint = `/api/v1/historical-connections${queryString ? `?${queryString}` : ""}`;

  return useQuery({
    queryKey: historicalKeys.connections(params),
    queryFn: () => apiRequest<HistoricalConnectionListResponse>(endpoint)
  });
}

export function useHistoricalConnectionMeta() {
  return useQuery({
    queryKey: historicalKeys.meta(),
    queryFn: () => apiRequest<HistoricalConnectionMetaResponse>("/api/v1/meta/historical-connections")
  });
}
