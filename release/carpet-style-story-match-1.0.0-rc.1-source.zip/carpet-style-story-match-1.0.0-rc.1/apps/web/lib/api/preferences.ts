import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "./client";
import {
  PreferenceAssessmentRead,
  PreferenceTextQuestionRead,
  TextResponseRead,
  TextChoiceEnum,
  VisualPresentationRead,
  VisualChoiceEnum,
  VisualResponseRead,
  UserPreferenceProfileResponse,
  PreferenceConfidenceProfileResponse,
  ImportanceProfileResponse,
  UserNarrativeProfileResponse
} from "../types/api";

// ---------------------------------------------------------
// QUERY KEYS
// ---------------------------------------------------------
export const preferenceKeys = {
  all: ["preferences"] as const,
  assessment: (id: string) => [...preferenceKeys.all, "assessment", id] as const,
  textMeta: () => [...preferenceKeys.all, "text-meta"] as const,
  textResponses: (id: string) => [...preferenceKeys.all, "text-responses", id] as const,
  textProfile: (id: string) => [...preferenceKeys.all, "text-profile", id] as const,
  visualPresentations: (id: string) => [...preferenceKeys.all, "visual-presentations", id] as const,
  visualResponses: (id: string) => [...preferenceKeys.all, "visual-responses", id] as const,
  visualProfile: (id: string) => [...preferenceKeys.all, "visual-profile", id] as const,
  userPreferenceProfile: (id: string) => [...preferenceKeys.all, "user-preference-profile", id] as const,
  confidenceProfile: (id: string) => [...preferenceKeys.all, "confidence-profile", id] as const,
  importanceProfile: (id: string) => [...preferenceKeys.all, "importance-profile", id] as const,
  narrativeMeta: () => [...preferenceKeys.all, "narrative-meta"] as const,
  narrativeProfile: (id: string) => [...preferenceKeys.all, "narrative-profile", id] as const
};

// ---------------------------------------------------------
// ASSESSMENT LIFECYCLE HOOKS
// ---------------------------------------------------------
export function useCreateAssessment() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: () =>
      apiRequest<PreferenceAssessmentRead>("/api/v1/preference-assessments", {
        method: "POST"
      }),
    onSuccess: (data) => {
      queryClient.setQueryData(preferenceKeys.assessment(data.id), data);
    }
  });
}

export function useAssessment(id: string) {
  return useQuery({
    queryKey: preferenceKeys.assessment(id),
    queryFn: () =>
      apiRequest<PreferenceAssessmentRead>(`/api/v1/preference-assessments/${id}`),
    enabled: Boolean(id)
  });
}

// ---------------------------------------------------------
// TEXT PREFERENCE HOOKS
// ---------------------------------------------------------
export function useTextQuestionsMeta() {
  return useQuery({
    queryKey: preferenceKeys.textMeta(),
    queryFn: () =>
      apiRequest<PreferenceTextQuestionRead[]>("/api/v1/meta/preference-text-questions")
  });
}

export function useTextResponses(assessmentId: string) {
  return useQuery({
    queryKey: preferenceKeys.textResponses(assessmentId),
    queryFn: () =>
      apiRequest<TextResponseRead[]>(`/api/v1/preference-assessments/${assessmentId}/text-responses`),
    enabled: Boolean(assessmentId)
  });
}

export function useSaveTextResponse(assessmentId: string) {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ questionKey, choice }: { questionKey: string; choice: TextChoiceEnum }) =>
      apiRequest<TextResponseRead>(
        `/api/v1/preference-assessments/${assessmentId}/text-responses/${questionKey}`,
        {
          method: "PUT",
          body: JSON.stringify({ choice })
        }
      ),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: preferenceKeys.textResponses(assessmentId) });
      queryClient.invalidateQueries({ queryKey: preferenceKeys.assessment(assessmentId) });
    }
  });
}

export function useCompleteTextAssessment(assessmentId: string) {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: () =>
      apiRequest<PreferenceAssessmentRead>(
        `/api/v1/preference-assessments/${assessmentId}/complete-text`,
        { method: "POST" }
      ),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: preferenceKeys.assessment(assessmentId) });
      queryClient.invalidateQueries({ queryKey: preferenceKeys.textProfile(assessmentId) });
    }
  });
}

// ---------------------------------------------------------
// VISUAL PREFERENCE HOOKS
// ---------------------------------------------------------
export function useStartVisualPhase(assessmentId: string) {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: () =>
      apiRequest<VisualPresentationRead[]>(
        `/api/v1/preference-assessments/${assessmentId}/start-visual`,
        { method: "POST" }
      ),
    onSuccess: (data) => {
      queryClient.setQueryData(preferenceKeys.visualPresentations(assessmentId), data);
      queryClient.invalidateQueries({ queryKey: preferenceKeys.assessment(assessmentId) });
    }
  });
}

export function useVisualPresentations(assessmentId: string) {
  return useQuery({
    queryKey: preferenceKeys.visualPresentations(assessmentId),
    queryFn: () =>
      apiRequest<VisualPresentationRead[]>(
        `/api/v1/preference-assessments/${assessmentId}/visual-presentations`
      ),
    enabled: Boolean(assessmentId)
  });
}

export function useVisualResponses(assessmentId: string) {
  return useQuery({
    queryKey: preferenceKeys.visualResponses(assessmentId),
    queryFn: () =>
      apiRequest<VisualResponseRead[]>(
        `/api/v1/preference-assessments/${assessmentId}/visual-responses`
      ),
    enabled: Boolean(assessmentId)
  });
}

export function useSaveVisualResponse(assessmentId: string) {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ stimulusKey, choice }: { stimulusKey: string; choice: VisualChoiceEnum }) =>
      apiRequest<VisualResponseRead>(
        `/api/v1/preference-assessments/${assessmentId}/visual-responses/${stimulusKey}`,
        {
          method: "PUT",
          body: JSON.stringify({ choice })
        }
      ),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: preferenceKeys.visualResponses(assessmentId) });
      queryClient.invalidateQueries({ queryKey: preferenceKeys.assessment(assessmentId) });
    }
  });
}

export function useCompleteVisualAssessment(assessmentId: string) {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: () =>
      apiRequest<PreferenceAssessmentRead>(
        `/api/v1/preference-assessments/${assessmentId}/complete-visual`,
        { method: "POST" }
      ),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: preferenceKeys.assessment(assessmentId) });
      queryClient.invalidateQueries({ queryKey: preferenceKeys.visualProfile(assessmentId) });
    }
  });
}

// ---------------------------------------------------------
// MULTIMODAL PROFILE & REVIEW HOOKS
// ---------------------------------------------------------
export function useBuildMultimodalProfile(assessmentId: string) {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: () =>
      apiRequest<UserPreferenceProfileResponse>(
        `/api/v1/preference-assessments/${assessmentId}/build-profile`,
        { method: "POST" }
      ),
    onSuccess: (data) => {
      queryClient.setQueryData(preferenceKeys.userPreferenceProfile(assessmentId), data);
      queryClient.invalidateQueries({ queryKey: preferenceKeys.assessment(assessmentId) });
      queryClient.invalidateQueries({ queryKey: preferenceKeys.confidenceProfile(assessmentId) });
    }
  });
}

export function useUserPreferenceProfile(assessmentId: string) {
  return useQuery({
    queryKey: preferenceKeys.userPreferenceProfile(assessmentId),
    queryFn: () =>
      apiRequest<UserPreferenceProfileResponse>(
        `/api/v1/preference-assessments/${assessmentId}/preference-profile`
      ),
    enabled: Boolean(assessmentId)
  });
}

export function useConfidenceProfile(assessmentId: string) {
  return useQuery({
    queryKey: preferenceKeys.confidenceProfile(assessmentId),
    queryFn: () =>
      apiRequest<PreferenceConfidenceProfileResponse>(
        `/api/v1/preference-assessments/${assessmentId}/confidence-profile`
      ),
    enabled: Boolean(assessmentId)
  });
}

export function useOverrideDimension(assessmentId: string) {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ dimensionKey, value }: { dimensionKey: string; value: number }) =>
      apiRequest<UserPreferenceProfileResponse>(
        `/api/v1/preference-assessments/${assessmentId}/preference-profile/dimensions/${dimensionKey}`,
        {
          method: "PUT",
          body: JSON.stringify({ value })
        }
      ),
    onSuccess: (data) => {
      queryClient.setQueryData(preferenceKeys.userPreferenceProfile(assessmentId), data);
    }
  });
}

export function useConfirmProfile(assessmentId: string) {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: () =>
      apiRequest<UserPreferenceProfileResponse>(
        `/api/v1/preference-assessments/${assessmentId}/confirm-profile`,
        { method: "POST" }
      ),
    onSuccess: (data) => {
      queryClient.setQueryData(preferenceKeys.userPreferenceProfile(assessmentId), data);
      queryClient.invalidateQueries({ queryKey: preferenceKeys.assessment(assessmentId) });
    }
  });
}

// ---------------------------------------------------------
// IMPORTANCE PROFILE HOOKS
// ---------------------------------------------------------
export function useCreateImportanceProfile(assessmentId: string) {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (payload: {
      skip?: boolean;
      priority_dimensions?: string[];
      flexible_dimensions?: string[];
    }) =>
      apiRequest<ImportanceProfileResponse>(
        `/api/v1/preference-assessments/${assessmentId}/importance-profile`,
        {
          method: "POST",
          body: JSON.stringify({
            skip: payload.skip ?? false,
            priority_dimensions: payload.priority_dimensions ?? [],
            flexible_dimensions: payload.flexible_dimensions ?? []
          })
        }
      ),
    onSuccess: (data) => {
      queryClient.setQueryData(preferenceKeys.importanceProfile(assessmentId), data);
      queryClient.invalidateQueries({ queryKey: preferenceKeys.assessment(assessmentId) });
    }
  });
}

export function useImportanceProfile(assessmentId: string) {
  return useQuery({
    queryKey: preferenceKeys.importanceProfile(assessmentId),
    queryFn: () =>
      apiRequest<ImportanceProfileResponse>(
        `/api/v1/preference-assessments/${assessmentId}/importance-profile`
      ),
    enabled: Boolean(assessmentId)
  });
}

// ---------------------------------------------------------
// NARRATIVE PROFILE HOOKS
// ---------------------------------------------------------
export function useCreateNarrativeProfile(assessmentId: string) {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (payload: {
      skip?: boolean;
      primary_themes?: string[];
      secondary_themes?: string[];
    }) =>
      apiRequest<UserNarrativeProfileResponse>(
        `/api/v1/preference-assessments/${assessmentId}/narrative-profile`,
        {
          method: "POST",
          body: JSON.stringify({
            skip: payload.skip ?? false,
            primary_themes: payload.primary_themes ?? [],
            secondary_themes: payload.secondary_themes ?? []
          })
        }
      ),
    onSuccess: (data) => {
      queryClient.setQueryData(preferenceKeys.narrativeProfile(assessmentId), data);
      queryClient.invalidateQueries({ queryKey: preferenceKeys.assessment(assessmentId) });
    }
  });
}

export function useUserNarrativeProfile(assessmentId: string) {
  return useQuery({
    queryKey: preferenceKeys.narrativeProfile(assessmentId),
    queryFn: () =>
      apiRequest<UserNarrativeProfileResponse>(
        `/api/v1/preference-assessments/${assessmentId}/narrative-profile`
      ),
    enabled: Boolean(assessmentId)
  });
}
