export interface HealthResponse {
  status: string;
  service: string;
}

export interface StyleDNAMetadata {
  total_dimensions: number;
  dimensions: Array<{
    code: string;
    key: string;
    label_tr: string;
    min_label: string;
    max_label: string;
  }>;
}

export interface NarrativeThemesMetadata {
  total_themes: number;
  themes: Array<{
    code: string;
    key: string;
    icon: string;
    label_tr: string;
    description: string;
  }>;
}

const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";

export async function fetchHealth(): Promise<HealthResponse> {
  const res = await fetch(`${API_BASE_URL}/api/v1/health`, {
    cache: "no-store",
  });
  if (!res.ok) {
    throw new Error(`Health check failed with status ${res.status}`);
  }
  return res.json();
}

export async function fetchStyleDNAMeta(): Promise<StyleDNAMetadata> {
  const res = await fetch(`${API_BASE_URL}/api/v1/meta/style-dna`, {
    cache: "no-store",
  });
  if (!res.ok) {
    throw new Error(`Style DNA metadata fetch failed with status ${res.status}`);
  }
  return res.json();
}

export async function fetchNarrativeThemesMeta(): Promise<NarrativeThemesMetadata> {
  const res = await fetch(`${API_BASE_URL}/api/v1/meta/narrative-themes`, {
    cache: "no-store",
  });
  if (!res.ok) {
    throw new Error(`Narrative themes metadata fetch failed with status ${res.status}`);
  }
  return res.json();
}
